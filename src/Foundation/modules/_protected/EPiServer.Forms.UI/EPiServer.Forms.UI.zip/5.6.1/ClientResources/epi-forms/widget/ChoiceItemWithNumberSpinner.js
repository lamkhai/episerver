define("epi-forms/widget/ChoiceItemWithNumberSpinner", [// dojo
"dojo/_base/declare", "dojo/_base/lang", "dojo/on", "dijit/form/RadioButton", "dijit/form/CheckBox", // epi-addons
"epi-forms/widget/_ChoiceItemWithExtendedWidget"], function ( // dojo
declare, lang, on, RadioButton, CheckBox, // epi-addons
_ChoiceItemWithExtendedWidget) {
  // module:
  //      epi-forms/widget/ChoiceItemWithNumberSpinner
  // summary:
  //
  // tags:
  //      public
  return declare([_ChoiceItemWithExtendedWidget], {
    _choiceControl: null,
    // =======================================================================
    // Protected stubs
    // =======================================================================
    _updateExtendedWidgetState: function _updateExtendedWidgetState(extendedWidget) {
      // summary:
      //      Enable/Disable the number spinner according to the state of the choice state
      // tags:
      //      protected
      var isEnabled = this._choiceControl.get("checked");

      extendedWidget.set("disabled", !isEnabled);
    },
    // =======================================================================
    // Public, overrided stubs
    // =======================================================================
    isValid: function isValid() {
      // summary:
      //      Return the current value is valid or not depend on children widget.
      // tags:
      //      public
      // the value of the widget is valid if
      // the selector is not selected
      // or selected but doesn't have any extended widget
      // or selected and have extended widget and the extended widget has value
      return !this._selector.get("checked") || !this._extendedWidget || this._extendedWidget.isValid();
    },
    _updateSelectorValue: function _updateSelectorValue(
    /*String*/
    value) {
      // summary:
      //       Update value for selector
      // value: [String]
      //
      // returns: [String]
      //
      // tags:
      //      override
      if (value === null || isNaN(value)) {
        return [value];
      }

      return this.inherited(arguments);
    },
    _getParams: function _getParams(item) {
      // summary:
      //      Return the object which includes every parameters to initialize the extended widget
      // item: [Object]
      //      Item data object used to build extended widget.
      // tags:
      //      override
      return {
        readOnly: item.readOnly,
        constraints: {
          min: parseInt(this.customizationMinValue),
          max: parseInt(this.customizationMaxValue),
          places: 0
        },
        rangeMessage: this.shortErrorMessage,
        missingMessage: this.shortErrorMessage,
        promptMessage: this.shortErrorMessage,
        invalidMessage: this.shortErrorMessage,
        required: true,
        smallDelta: 1
      };
    },
    _getAllowPreviewableTextBoxItems: function _getAllowPreviewableTextBoxItems() {
      // summary:
      //     return a list from the module settings.
      // tags:
      //      override
      return this.extendedWidgetOptions;
    },
    _createRadioButtonWidget: function _createRadioButtonWidget() {
      // summary:
      //      Create RadioButton widget.
      // returns: [Object]
      //      An instance of 'dijit/form/RadioButton' class.
      // tags:
      //      override
      this._setupChoiceControl(function (params) {
        return new RadioButton(params);
      });

      return this._choiceControl;
    },
    _createCheckBoxWidget: function _createCheckBoxWidget() {
      // summary:
      //      Create Checkbox widget in a specific group if the [name] parameter is passed in.
      // returns: [Object]
      //      An instance of 'dijit/form/CheckBox' class.
      // tags:
      //      override
      this._setupChoiceControl(function (params) {
        return new CheckBox(params);
      });

      return this._choiceControl;
    },
    _doSetupExtendedWidget: function _doSetupExtendedWidget(
    /*Object*/
    item,
    /*Object*/
    extendedWidget) {
      // summary:
      //      Do the setup for the number spinner
      // tags:
      //      override
      this._updateExtendedWidgetState(extendedWidget); // To assure that the code to set the state of the extended widget
      // run after the selector value is changed


      this.connect(this.parent, "onSelectorsValueSet", lang.hitch(this, function () {
        this._updateExtendedWidgetState(extendedWidget);
      }));
    },
    _getExtendedWidgetValue: function _getExtendedWidgetValue(
    /*Object*/
    item) {
      // summary:
      //      Gets stored value to display on the extended widget.
      // item: [Object]
      //      Item data object used to build extended widget.
      // returns: [Number]
      //      Value to display on the extended widget.
      // tags:
      //      override
      var extendedWidgetValue = this.inherited(arguments);
      return parseInt(extendedWidgetValue);
    },
    _setupChoiceControl: function _setupChoiceControl(createChoiceControl) {
      // summary:
      //      Setup widget control based on the control type (RadioButton or CheckBox)
      // isRadioButton: [bool]
      //      Flag to indicate current widget control is RadioButton or CheckBox
      // tags:
      //      private
      var params = {}; // make sure radio buttons are grouped with same name in case of displaying multiple editor (compare view)

      params.name = this.parent.id;

      if (this.name !== "") {
        params.name = params.name + this.name;
      }

      this._choiceControl = createChoiceControl(params);
      on(this._choiceControl, "click", lang.hitch(this, function () {
        this.emit("_itemWidgetControlClick", this);
      }));
    }
  });
});