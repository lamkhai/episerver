define("epi-forms/widget/TargetPageEditor", [// dojo
"dojo/_base/declare", "dojo/aspect", // epi-cms
"epi-cms/contentediting/editors/LinkItemEditor", "epi-cms/widget/command/DefaultContentSelectorPlugAndPlayCommand", // epi-addons
"epi-forms/widget/TargetPageDialogEditor", "epi-forms/widget/FormsContentSelectorPlugAndPlay", // resources
"epi/i18n!epi/cms/nls/episerver.forms.editview", "epi/i18n!epi/cms/nls/episerver.cms.contentediting.editors.itemcollection"], function ( // dojo
declare, aspect, // epi-cms
LinkItemEditor, DefaultContentSelectorPlugAndPlayCommand, //epi-addons
TargetPageDialogEditor, FormsContentSelectorPlugAndPlay, // resources
resources, linkResources) {
  return declare([LinkItemEditor], {
    _addLinkCommand: null,
    _setupDialogSettings: function _setupDialogSettings() {
      // summary:
      //      Setup settings for dialog.
      // tags:
      //      Override
      this.inherited(arguments);
      this.dialogSettings = Object.assign(this.dialogSettings, {
        title: this._getTitle(),
        dialogContentClass: TargetPageDialogEditor,
        dialogClass: "epi-dialog-portrait",
        destroyOnHide: false,
        defaultActionsVisible: false
      });
    },
    _setupContentSelector: function _setupContentSelector() {
      this._addLinkCommand = this._addLinkCommand || new DefaultContentSelectorPlugAndPlayCommand({
        contentSelectorDialogSettings: this.contentSelectorDialogSettings,
        dialogSettings: this.dialogSettings,
        label: linkResources.emptyactions.buttonlabel,
        canExecute: true
      });
      this.contentSelectorPnP = new FormsContentSelectorPlugAndPlay({
        actionsNodeOptions: this.actionsNodeOptions || {},
        dialogSettings: this.dialogSettings,
        contentSelectorDialogSettings: this.contentSelectorDialogSettings,
        readOnly: this.readOnly,
        isVisible: !this.get("value"),
        // only show for initial state.
        isInQuickEditMode: this.isInQuickEditMode,
        quickEditBlockId: this.quickEditBlockId,
        commands: [].concat(this._addLinkCommand)
      });
      ["onContentSelectorChange", "onSearchResultSelected", "onDialogExecute", "onDialogHide", "onDialogShow"].forEach(function (callbackName) {
        this.contentSelectorPnP.own(aspect.after(this._addLinkCommand, callbackName, function () {
          this.contentSelectorPnP[callbackName].apply(this, arguments);
        }.bind(this), true));
      }.bind(this));
      this.contentSelectorPnP.placeAt(this.contentSelectorContainer || this.domNode);
      this.contentSelectorPnP.startup();
      this.own(this.contentSelectorPnP, aspect.after(this.contentSelectorPnP, "onContentSelectorChange", this._onContentSelectorChange.bind(this), true), aspect.after(this.contentSelectorPnP, "onSearchResultSelected", this._onSearchResultSelected.bind(this), true), aspect.after(this.contentSelectorPnP, "onDialogExecute", this._onDialogExecute.bind(this), true), aspect.after(this.contentSelectorPnP, "onDialogHide", this._onDialogHide.bind(this), true), aspect.after(this.contentSelectorPnP, "onDialogShow", this._onDialogShow.bind(this), true));
    },
    _getTitle: function _getTitle() {
      // summary:
      //      Get title for the dialog.
      // tags:
      //      Override
      return this.value ? resources.editpage : resources.selectpage;
    }
  });
});