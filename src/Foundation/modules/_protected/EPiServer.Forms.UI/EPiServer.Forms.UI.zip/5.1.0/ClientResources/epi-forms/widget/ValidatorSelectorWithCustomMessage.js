define("epi-forms/widget/ValidatorSelectorWithCustomMessage", [// dojo
"dojo/_base/declare", "dojo/_base/lang", "dojo/aspect", "dojo/dom-construct", "dojo/dom-style", // epi-addons
"epi-forms/ModuleSettings", "epi-forms/widget/CustomMessageTextBox", "epi-forms/widget/ChoiceItemWithPreviewableText", "epi-forms/widget/_CustomValidationMessageMixin"], function ( // dojo
declare, lang, aspect, domConstruct, domStyle, // epi-addons
ModuleSettings, CustomMessageTextBox, ChoiceItemWithPreviewableText, _CustomValidationMessageMixin) {
  // module:
  //      epi-forms/widget/ValidatorSelectorWithCustomValidationMessage
  // summary:
  //      extends ChoiceItemWithPreviewableText to add a textbox for entering custom validator message
  // tags:
  //      public
  return declare([ChoiceItemWithPreviewableText, _CustomValidationMessageMixin], {
    // =======================================================================
    // Public, overrided stubs
    // =======================================================================
    buildRendering: function buildRendering() {
      this.inherited(arguments);

      this._setupCustomValidationMessageWidget(this.item);
    },
    // =======================================================================
    // Protected stubs
    // =======================================================================
    _setSelectorCheckedAttr: function _setSelectorCheckedAttr(value) {
      // summary:
      //      Sets 'checked' attribute value for selector widget.
      // tags:
      //      protected
      this._selector && this._selector.set("checked", value, false);

      this._toggleValidatorMessageTextBoxDisplay();
    },
    // =======================================================================
    // Private stubs
    // =======================================================================
    _setupCustomValidationMessageWidget: function _setupCustomValidationMessageWidget(
    /*Object*/
    item) {
      // summary:
      //      set up a textbox for entering custom validator message
      var textBox = new CustomMessageTextBox({
        defaultValidatorMessage: this.defaultValidatorMessage,
        formEditingViewModel: this.formEditingViewModel,
        currentValidatorType: this.searchConditions.key
      });
      textBox.startup();
      domConstruct.place(textBox.domNode, this.selectorContainer, "last");
      this._validationMessageTextBox = textBox;
      this.own(aspect.after(this._selector, "onChange", lang.hitch(this, function (e) {
        this._toggleValidatorMessageTextBoxDisplay(); // If the checkbox for a validator is checked, set the default value for its custom validation textbox


        if (this._getSelectorCheckedAttr()) {
          var validatorMessage = this._validationMessageTextBox.get("value") || this.defaultValidatorMessage;

          this._validationMessageTextBox.set("value", validatorMessage);

          var validatorType = this.searchConditions.key;

          this._updateModelValidatorMessagesProperty(validatorType, validatorMessage);
        }
      }), true), this.connect(this._validationMessageTextBox, "onChange", this._updateCustomMessage));
    },
    _setCustomValidatorMessageValueAttr: function _setCustomValidatorMessageValueAttr(value) {
      // value is null means that the current validator is selected in master language,
      // and we are in another language (the message is null because we haven't set value
      // for it in this language).In this case, just set default value (in this language)
      // for the message.
      var message = value || this.defaultValidatorMessage;

      if (value === null) {
        var validatorType = this.searchConditions.key;

        this._updateModelValidatorMessagesProperty(validatorType, message);
      }

      this._validationMessageTextBox && this._validationMessageTextBox.set("value", message);
    },
    _setCustomValidatorMessageReadonlyAttr: function _setCustomValidatorMessageReadonlyAttr(value) {
      this._validationMessageTextBox && this._validationMessageTextBox.set("readonly", value);
    },
    _toggleValidatorMessageTextBoxDisplay: function _toggleValidatorMessageTextBoxDisplay() {
      // summary:
      //      toggle display of custom message textbox based on validator selector checked
      var isSelected = this._getSelectorCheckedAttr(),
          displayAttrValue = isSelected === true ? "" : "none";

      domStyle.set(this._validationMessageTextBox.customMessageContainer, "display", displayAttrValue);
    },
    _updateCustomMessage: function _updateCustomMessage(
    /*String*/
    value) {
      this.emit("selectorChanged");
    }
  });
});