define("epi-forms/widget/viewmodels/FormsDataViewModel", [// dojo
"dojo/_base/declare", "dojo/_base/lang", "dojo/Deferred", "dojo/Stateful", "dojo/when", // epi
"epi/shell/DestroyableByKey", "epi/dependency", "epi-cms/_ContentContextMixin", // epi-addons
"epi-forms/widget/Downloader"], function ( // dojo
declare, lang, Deferred, Stateful, when, // epi
DestroyableByKey, dependency, _ContentContextMixin, // epi-addons
Downloader) {
  return declare([Stateful, DestroyableByKey, _ContentContextMixin], {
    // store: [readonly] Rest store
    //      The form data store
    store: null,
    postscript: function postscript() {
      // summary:
      //      Setup mixed in properties
      // tags:
      //      protected
      var registry = dependency.resolve("epi.storeregistry");
      this.store = registry.get("epi-forms.formsdata");
      this.inherited(arguments);
      this.set("store", this.store);
      when(this.getCurrentContext(), lang.hitch(this, function (context) {
        this._fetchData(context);
      }));
    },
    contentContextChanged: function contentContextChanged(context, callerData) {
      // summary:
      //      Fetching data when the context change.
      // tags:
      //      override
      this.inherited(arguments); // reset beginDate and endDate fields when context changed

      this.set("beginDate", null);
      this.set("endDate", null);
      this.set("finalizedOnly", false);
      this.set("columnSelect", null);
      this.set("filterText", null);

      this._fetchData(context);
    },
    getColumns: function getColumns() {
      var def = new Deferred();
      when(this.getCurrentContext(), lang.hitch(this, function (context) {
        when(this.store.query({
          query: "getcolumns",
          parent: context.id
        }), lang.hitch(this, function (items) {
          def.resolve(items);
        }));
      }));
      return def;
    },
    getChartData: function getChartData(beginDate, endDate, finalizedOnly, columnSelect, filterText) {
      // summary:
      //      Get data to draw chart
      // tags:
      //      public
      var def = new Deferred();
      when(this.getCurrentContext(), lang.hitch(this, function (context) {
        when(this.store.query({
          query: "getchartdata",
          parent: context.id,
          beginDate: beginDate,
          endDate: endDate,
          finalizedOnly: finalizedOnly,
          columnSelect: columnSelect,
          filterText: filterText
        }), lang.hitch(this, function (data) {
          def.resolve(data);
        }));
      }));
      return def;
    },
    exportData: function exportData(exporter, submissionIds, beginDate, endDate, finalizedOnly, columnSelect, filterText, callback) {
      // summary:
      //      Get exported data file
      // tags:
      //      public
      // with the specific exporter and submissionIds, and queries filter, we have enough info to download the file
      Downloader.download({
        contentLink: this._currentContext.id,
        exporterName: exporter.name,
        extension: exporter.exportFileExtension,
        submissionIds: submissionIds,
        beginDate: beginDate,
        endDate: endDate,
        finalizedOnly: finalizedOnly,
        columnSelect: columnSelect,
        filterText: filterText
      }, callback);
    },
    deleteByQuery: function deleteByQuery(queryObject) {
      // summary:
      //      Delete all posts by query
      // tags:
      //      public
      var def = new Deferred();
      when(this.store.executeMethod("DeleteByQuery", null, queryObject), lang.hitch(this, function (result) {
        def.resolve(result);
      }));
      return def;
    },
    deleteData: function deleteData(submissionIds) {
      // summary:
      //      Delete selected posts
      // tags:
      //      public
      var def = new Deferred();
      when(this.store.executeMethod("DeleteData", null, {
        contentLink: this._currentContext.id,
        submissionIds: submissionIds
      }), lang.hitch(this, function (result) {
        def.resolve(result);
      }));
      return def;
    },
    _fetchData: function _fetchData(context) {
      // summary:
      //      Fetch data from store
      // tags:
      //      private
      this.set("query", {
        parent: context.id
      });
    }
  });
});