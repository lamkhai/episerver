define("epi-forms/dgrid/Formatters", [// dojo
"dojo/date/locale", // epi
"epi/shell/dgrid/Formatter", "epi/shell/dgrid/util/misc"], function ( // dojo
locale, // epi
Formatter, GridMiscUtil) {
  // module:
  //      epi-forms/dgrid/Formatters
  // summary:
  //      Register custom formatters to dgrid that used in EPiServer Forms addon.
  //      Formatters:
  //          richTextTemplate
  //          dateTimeFormatter
  //          embededLinksFormatter
  //          encodeAndEllipsisFormatter
  //          removeNullValueFormatter
  // tags:
  //      public
  var module = {
    richTextTemplate: function richTextTemplate(
    /*Object*/
    value) {
      // summary:
      //      Message template formatter.
      //      Enable HTML content display in dgrid.
      // value: [Object]
      //      Text that desired to show as HTML content.
      // tags:
      //      public
      return value;
    },
    dateTimeFormatter: function dateTimeFormatter(
    /*Object*/
    value) {
      // summary:
      //      Returns formate of DateTime as "yyyy-MM-dd HH:mm:ss".
      // tags:
      //      public
      return locale.format(new Date(value), {
        datePattern: "yyyy-MM-dd",
        timePattern: "HH:mm:ss"
      });
    },
    embededLinksFormatter: function embededLinksFormatter(
    /*Object*/
    value) {
      // summary:
      //      Returns clickable links from upploaded file urls
      // tags:
      //      public
      var emptyResult = "";

      if (!value) {
        return emptyResult;
      }

      var relativePaths = value.split("|");

      if (relativePaths.length < 1) {
        return emptyResult;
      }

      var links = [];
      relativePaths.forEach(function (item) {
        var fileUrl = item.trim();

        if (!fileUrl) {
          return emptyResult;
        }

        var indexSharp = fileUrl.indexOf("#@"),
            namePart = fileUrl.substr((~-indexSharp >>> 0) + 3); // replace "+ 3" with "+ 1" to include the #@

        if (namePart) {
          fileUrl = fileUrl.slice(0, indexSharp);
        } else {
          namePart = fileUrl.substr((~-fileUrl.lastIndexOf("/") >>> 0) + 2); // replace "+ 2" with "+ 1" to include the /
        } // If Forms is working on encryption mode or file name does not follow the pre-defined standard, the input for this method is not well formated because it is encrypted.
        // In that case we just display cipher text on the link


        var linkText = namePart ? GridMiscUtil.htmlEncode(namePart) : GridMiscUtil.htmlEncode(fileUrl);
        links.push('<a class="epi-fileUpload" target="_blank" href="' + fileUrl + '">' + linkText + "</a>");
      });
      return links.join(", ");
    },
    encodeAndEllipsisFormatter: function encodeAndEllipsisFormatter(
    /*Object*/
    value) {
      // summary:
      //      Returns encode and ellipsis of input value.
      // tags:
      //      public
      return GridMiscUtil.ellipsis(GridMiscUtil.htmlEncode(value));
    },
    removeNullValueFormatter: function removeNullValueFormatter(
    /*Object*/
    value) {
      // summary:
      //      Returns empty string instead of null to display on grid.
      // tags:
      //      public
      return value == null ? "" : value.toString(); // cast to string, so number can be display in the dgrid
    },
    checkedFormatter: function checkedFormatter(
    /*Boolean*/
    value) {
      // summary:
      //      Returns check symbol if the value is true, otherwise return empty string.
      // tags:
      //      public
      return value === true ? "<div class='epi-iconCheckmark'></div>" : "";
    }
  };
  Formatter.addFormatter("richTextTemplate", module.richTextTemplate);
  Formatter.addFormatter("dateTimeFormatter", module.dateTimeFormatter);
  Formatter.addFormatter("embededLinksFormatter", module.embededLinksFormatter);
  Formatter.addFormatter("encodeAndEllipsisFormatter", module.encodeAndEllipsisFormatter);
  Formatter.addFormatter("removeNullValueFormatter", module.removeNullValueFormatter);
  Formatter.addFormatter("checkedFormatter", module.checkedFormatter);
  return module;
});