﻿define("epi-ecf-ui/widget/MoveDiscountSelector", [
    // dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/dom-class",
    // dijit
    "dijit/form/Select",
    // epi
    "epi/dependency",
    "./SearchMenuItem",
    "epi/shell/dgrid/util/misc"
], function (
    // dojo
    array,
    declare,
    domClass,
    // dijit
    Select,
    // epi
    dependency,
    SearchMenuItem,
    shellMisc
) {
    return declare([Select], {
        // summary:
        //      Represents the widget which contains the move discount selector.
        // tags:
        //    internal product

        style: {width: '100%'},

        store: null,
        queryName: "getpromotions",
        typeIdentifiers: "episerver.commerce.marketing.promotiondata",
        limitItems: 5,
        
        campaignRootFolder: null,
        _searchMenu: null,
        excludedLink: null,

        postscript: function() {
            this.baseClass = this.baseClass + " epi-move-discount-selector";
            this.inherited(arguments);
        },

        postCreate: function() {
            this.inherited(arguments);

            var contentRepositoryDescriptors = dependency.resolve("epi.cms.contentRepositoryDescriptors");
            this.campaignRootFolder = this.campaignRootFolder || contentRepositoryDescriptors.marketing.roots[0];

            this.store = this.store || dependency.resolve("epi.storeregistry").get("epi.cms.content.light");

            this.addOption({ isSearchMenu: true});
            this._searchMenu = new SearchMenuItem({ 
                ownerDocument: this.ownerDocument
            });
            this.own(this._searchMenu,
                this._searchMenu.on("searchtext", function(data){
                    this.refresh(data.queryText);
                }.bind(this))
            );
            this.dropDown.addChild(this._searchMenu);
        },

        reset: function() {
            var selectedValue = this.get('value');
            if (selectedValue) {
                var selectedOption = this.getOptions(selectedValue);
                selectedOption.selected = false;

                var selectedNode = this.dropDown.getChildren().filter(function(child) {
                    return child.label === selectedOption.label;
                })[0];
                domClass.toggle(selectedNode.domNode, this.baseClass.replace(/\s+|$/g, "SelectedOption "), false);
                selectedNode.domNode.setAttribute("aria-selected", "false");
            }

            this._set('value', '');
            this._setDisplay();
            
            this.inherited(arguments);
        },

        refresh: function (queryText) {
            this._removeOption();
            if (this.store) {
                this.store.query(this._getQuery(queryText), {
                    start: 0,
                    count: this.limitItems
                }).then(this._addOptions.bind(this));
            }
        },

        _removeOption: function() {
            this.options = this.options.filter(function(item) { 
                return item.isSearchMenu; 
            });
            this._getChildren().forEach(function(widget) {
                widget.destroyRecursive();
            });
        },

        _getQuery: function(filterByName) {
            return {
                query: this.queryName, 
                referenceId: this.campaignRootFolder,
                typeIdentifiers: this.typeIdentifiers,
                isActiveOrPendingOnly: true,
                excludedContentLink: this.excludedLink,
                filterByName: filterByName
            };
        },

        _addOptions: function (results) {
            array.forEach(results, function (promotion) {
                this.addOption({ value: promotion.contentLink, label: shellMisc.ellipsis(shellMisc.htmlEncode(promotion.name)) });
            }.bind(this));
        },

        /* Override dijit.form.select widget. */
        _loadChildren: function(){
            this.inherited(arguments, [true]);
        },

        _getChildren: function(){
            if(!this.dropDown){
                return [];
            }
            var children = this.dropDown.getChildren();
            return children.filter(function(child) {
                return !child.isSearchMenu;
            });
        },

        _addOptionItem: function(option) {
            if (option.isSearchMenu) {
                return;
            }
            this.inherited(arguments);
        }
    });
});