﻿define("epi-ecf-ui/widget/viewmodel/FacetGroupListViewModel", [
// dojo
    "dojo/_base/declare",
    "dojo/Stateful",
    "dojo/when",
//dijit
    "dijit/Destroyable",
// epi
    "epi/dependency"
], function (
// dojo
    declare,
    Stateful,
    when,
//dijit
    Destroyable,
// epi
    dependency
) {

    return declare([Stateful, Destroyable], {
        // summary:
        //      View model for "FacetGroupList" widget.
        // tags:
        //      public

        // facetGroups: [public] Array
        //      The collection of facet group.
        facetGroups: [],

        facetFilters: [],

        // facetFiltersService: [public] Object
        //      The facet filter service. Default is campaign facets.
        facetFiltersService: null,

        contentStoreKeyName: "epi.cms.content.light",
        facetStoreKeyName: "epi.commerce.facet",

        contentStore: null,
        facetStore: null,

        _hashFacetFiltersGetter: function () {
            // summary:
            //      Gets latest facet filters information from URL.
            // returns: [Array]
            //      Collection of object in { id: [string], values: [Array] } format.
            // tags:
            //      protected

            return this.facetFiltersService.getFilters();
        },

        postscript: function () {
            this.inherited(arguments);

            this.facetFiltersService = this.facetFiltersService || dependency.resolve("epi.commerce.FacetFiltersService");

            var registry = dependency.resolve("epi.storeregistry");
            this.contentStore = this.contentStore || registry.get(this.contentStoreKeyName);
            this.facetStore = this.facetStore || registry.get(this.facetStoreKeyName);

            this._campaignRootFolder = this._campaignRootFolder || dependency.resolve("epi.cms.contentRepositoryDescriptors").marketing.roots[0];
        },

        fetchData: function () {
            // summary:
            //      Gets facets data.
            // tags:
            //      public

            when(this._getData(), function (facet) {
                if (!facet || !facet.groups) {
                    return;
                }
                // facet.groups.forEach(function(group){
                //     if (group.id !== "status") {
                //         group.items.unshift({id: "All", name: "All", isDefault: true, isShowInUI: true});
                //     }
                // });
                this.set("facetGroups", facet.groups);
                this.setDefaultFilters();
            }.bind(this));
        },

        setDefaultFilters: function() {
            this.facetGroups.forEach(function(group, index) {
                var defaultItems = group.items.filter(function(item) {
                    return item.isDefault;
                });
                var defaultItem = [];
                if (defaultItems.length > 0) {
                    defaultItem.push(defaultItems[0].id);
                }
                this.updateFacetFilter(group.id, defaultItem);
            }.bind(this));
        },

        updateFacetFilter: function (key, values) {
            // summary:
            //      Updates facet filter with the given key and values.
            // key: [string]
            //      Facet filter key.
            // values: [Array]
            //      Facet filter values.
            // tags:
            //      public

            var _facetFilters = this.get("facetFilters"),
                keyIndex = -1;

            if (_facetFilters) {
                _facetFilters.forEach(function (item, index) {
                    if (item.id === key) {
                        keyIndex = index;
                        return;
                    }
                });
            }

            // Delete existing filter if the group do not have values.
            if (values.every(function (item) { return !item; })) {
                if (keyIndex !== -1) {
                    _facetFilters.splice(keyIndex, 1);
                }
                this.set("facetFilters", _facetFilters);
                this.refreshHashFacetFilters(_facetFilters);
                return;
            }

            if (keyIndex !== -1) {
                // Update existing group setting.
                _facetFilters[keyIndex].values = values;
            } else {
                // Add new setting
                _facetFilters.push({
                    "id": key,
                    values: values
                });
            }

            this.set("facetFilters", _facetFilters);
            this.refreshHashFacetFilters(_facetFilters);
        },

        refreshHashFacetFilters: function (facetFilters) {
            // summary:
            //      Updates latest facet filters to URL.
            // tags:
            //      public

            var newFilters = this.facetFiltersService.filtersToHash(facetFilters);
            this.facetFiltersService.updateFilters(newFilters);
        },

        _getData: function () {
            // summary:
            //      Gets facets data.
            //      Should implements this function in concrete class in order to returns data that fetched from server.
            // tags:
            //      protected, extensions
            
            var query = {
                "id": this.facetFiltersService.hashKey,
                facetString: this.facetFiltersService.getFiltersAsJson(),
                parentLink: this._campaignRootFolder
            };

            return this.facetStore.query(query);
        }

    });

});