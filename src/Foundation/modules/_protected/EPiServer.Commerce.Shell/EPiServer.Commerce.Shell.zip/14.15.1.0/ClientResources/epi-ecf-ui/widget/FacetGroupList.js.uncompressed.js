require({cache:{
'url:epi-ecf-ui/widget/templates/FacetGroupList.html':"﻿﻿<div class=\"epi-facet-list\">\r\n    <div data-dojo-attach-point=\"containerNode\"></div>\r\n</div>"}});
﻿define("epi-ecf-ui/widget/FacetGroupList", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/aspect",
    "dojo/topic",
// dijit
    "dijit/layout/_LayoutWidget",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
// epi
    "epi/dependency",
    "epi/shell/widget/_ModelBindingMixin",

    "./FacetFilter",
// resources
    "dojo/text!./templates/FacetGroupList.html"
], function (
// dojo
    declare,
    lang,
    aspect,
    topic,
// dijit
    _LayoutWidget,
    _TemplatedMixin,
    _WidgetsInTemplateMixin,
// epi
    dependency,
    _ModelBindingMixin,

    FacetFilter,
// resources
    template
) {

    return declare([_LayoutWidget, _TemplatedMixin, _WidgetsInTemplateMixin, _ModelBindingMixin], {
        // summary:
        //      Represents the widget to filter list of campaigns.
        // tags:
        //      public

        modelBindingMap: {
            facetGroups: ["facetGroups"]
        },

        _setFacetGroupsAttr: function (facetGroups) {
            // summary:
            //      Renders facet groups.
            // facetGroups: [Array]
            //      Collection of facet group.
            // tags:
            //      protected

            facetGroups.forEach(function (facetGroup) {
                var existedFacet = this.getChildren().filter(function (child) { 
                    return child.facetId === facetGroup.id;
                })[0];
                if (existedFacet) {
                    return;
                }

                var facetGroupWidget = this._createFacetGroupWidget(facetGroup);
                this.addChild(facetGroupWidget);

                this.own(
                    facetGroupWidget,
                    facetGroupWidget.on("filterChanged", this._onSelectionChanged.bind(this))
                );
            }, this);

            this.updateFacetGroupWidgets();
        },

        // facetFiltersService: [public] Object
        //      The facet filter service. May pass a customized service. Otherwise it's campaign service.
        facetFiltersService: null,

        // listViewModelClass: [public] string
        //      Facet group list view model class.
        listViewModelClass: null,

        // templateString: [public] string
        //      Used by _TemplatedMixin.
        templateString: template,

        postMixInProperties: function () {
            // tags:
            //      protected, extensions

            // Resolves the campaign facet filter service, if not set.
            this.facetFiltersService = this.facetFiltersService || dependency.resolve("epi.commerce.FacetFiltersService");

            this.inherited(arguments);
            // Gets or creates a new instance of view model class.
            // Passes the facet filter service to the model class.
            this.model = this.model || new this.listViewModelClass({ facetFiltersService: this.facetFiltersService });
        },

        postCreate: function () {
            // tags:
            //      protected, extensions

            this.inherited(arguments);

            // Fetches facet groups data in order to render the list of facet group.
            this.model.fetchData();

            // Each time turned back to main view, refresh this widget.
            this.own(
                aspect.around(topic, "publish", this._aroundTopicPublish.bind(this)),
                topic.subscribe("/epi/shell/action/viewchanged", this._onViewChanged.bind(this))
            );
        },

        resetFilters: function() {
            this.model.set("facetFilters", []);
            this.model.refreshHashFacetFilters([]);
        },

        setDefaultFilters: function() {
            if (this.model.get("facetFilters").length === 0) {
                this.model.setDefaultFilters();
            }
        },

        refresh: function () {
            // summary:
            //      Refresh all facet groups.
            // tags:
            //      public
        },

        _createFacetGroupWidget: function (facetGroup) {
            // summary:
            //      Creates facet group widget based on the given settings.
            // facetGroup: [Object]
            //      Facet group settings.
            // returns: [Object]
            //      An instance of "epi-ecf-ui/widget/FacetFilter" widget.
            // tags:
            //      private

            return new FacetFilter({
                name: facetGroup.name,
                facetContainer: this.facetFiltersService.hashKey,
                facetId: facetGroup.id,
                items: facetGroup.items,
                isSearchable: facetGroup.settings.isSearchable,
                isUpdatable: facetGroup.settings.isUpdatable
            });
        },

        updateFacetGroupWidgets: function () {
            var hashFacetFilters = this.model.get("hashFacetFilters");
            this.model.set("facetFilters", hashFacetFilters);

            this.getChildren().forEach(function (groupWidget) {
                var facetFilter = hashFacetFilters.filter(function (item) {
                    return item.id === groupWidget.facetId;
                })[0];

                groupWidget.set("selection", facetFilter ? facetFilter.values : []);
            }, this);
        },

        _onViewChanged: function (type, args, data) {
            if (data.viewName === undefined) {
                return;
            }

            if (data.viewName === "discountpriorityview" && this.get("currentView") !== data.viewName) {
                this._refreshFacetWidgets();
            }
            this._set("currentView", data.viewName);
        },

        _refreshFacetWidgets: function () {
            var needToUpdateWidget = false;
            this.getChildren().forEach(function (groupWidget) {
                if (groupWidget.isUpdatable) {
                    groupWidget.destroy();
                    needToUpdateWidget = true;
                }
            });

            if (needToUpdateWidget) {
                this.model.fetchData();
            }
        },

        _onSelectionChanged: function (evt) {
            this.model.updateFacetFilter(evt.id, evt.items);
        },

        _aroundTopicPublish: function (original) {
            return function (item) {
                // intercept context changed event, adding view name to keep the view of discount priority.
                // This's because when the facet filter was set, the hash changed and fired context changed event.
                // The event fired without view name, the context loaded with default context view name, in this case is marketing overview.
                if (item === "/epi/shell/context/request") {
                    if (this.get("currentView") === "discountpriorityview") {
                        var data = arguments[2];
                        if (data && data.sender && data.sender._hashChanged) {
                            arguments[2] = lang.delegate(data, { viewName: "discountpriorityview" }); // jshint ignore:line
                        }
                    }
                }
                
                return original.apply(topic, arguments);
            }.bind(this);
        }
    });
});