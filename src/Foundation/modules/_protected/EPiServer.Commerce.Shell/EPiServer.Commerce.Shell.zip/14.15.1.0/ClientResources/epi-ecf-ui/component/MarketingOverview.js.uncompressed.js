require({cache:{
'url:epi-ecf-ui/component/templates/MarketingOverview.html':"<div class=\"epi-marketing-overview-container\">\r\n    <div class=\"epi-marketing-pagetitle\">Marketing</div>\r\n    <div data-dojo-attach-point=\"toolbarContainer\" class=\"epi-viewHeaderContainer epi-localToolbar clearfix\"></div>\r\n    <div data-dojo-type=\"epi-ecf-ui/widget/CampaignItemList\" data-dojo-attach-point=\"campaignItemList\"></div>\r\n</div>"}});
define("epi-ecf-ui/component/MarketingOverview", [
    "dojo/_base/declare",
    "dojo/dom-geometry",
    "dojo/when",
    "dojo/topic",
// dijit
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/layout/_LayoutWidget",
    "dijit/registry",
// epi
    "epi/shell/_ContextMixin",
    "epi/shell/widget/SearchBox",
    "../widget/FacetGroupList",
    "../widget/MarketingToolbar",
    "../widget/viewmodel/FacetGroupListViewModel",
// resources
    "dojo/text!./templates/MarketingOverview.html",
    "epi/i18n!epi/cms/nls/commerce.components.marketing",
// Widgets in the template
    "../widget/CampaignItemList"
], function (
    declare,
    domGeometry,
    when,
    topic,
// dijit
    _TemplatedMixin,
    _WidgetsInTemplateMixin,
    _LayoutWidget,
    _Registry,
// epi
    _ContextMixin,
    SearchBox,
    FacetGroupList,
    MarketingToolbar,
    FacetGroupListViewModel,    
// resources
    template,
    resources
) {
    return declare([_LayoutWidget, _TemplatedMixin, _WidgetsInTemplateMixin, _ContextMixin], {
        // summary:
        //      This is the initializer of Marketing Overview.

        templateString: template,
        resources: resources,

        viewName: "marketingoverview",

        postCreate: function () {
            this._toolbar = new MarketingToolbar({
                viewName: this.viewName
            });
            this.own(this._toolbar);
            this._toolbar.placeAt(this.toolbarContainer);

            var campaignFacetSettings = {
                listViewModelClass: FacetGroupListViewModel,
                region: "leading"
            };
            this._campaignFacet = new FacetGroupList(campaignFacetSettings);
            this.own(
                this._campaignFacet,
                this.campaignItemList.on("campaignlistupdate", this.highlightNewlyInsertedRow.bind(this))
            );

            this.searchBox = new SearchBox({
                "class": "epi-search--full-width",
                placeHolder: resources.searchplaceholder,
                triggerChangeOnEnter: false
            });
            this.own(this.searchBox,
                this.searchBox.on("searchBoxChange", this._onFilterChanged.bind(this))
            );

            this.searchBox.placeAt(this._campaignFacet, "first");

            this._toolbar.addChild(this._campaignFacet);

            this.clearFilter();
            this.inherited(arguments);

            this._setupEvents();
        },

        _setupEvents: function () {
            this.own(
                topic.subscribe("/dojo/hashchange", this._onHashChanged.bind(this))
            );
        },

        _onHashChanged: function (newHash) {
            this._campaignFacet.updateFacetGroupWidgets();
            this.campaignItemList.refresh();
        },

        updateView: function (data, context) {
            // summary:
            //      Updates the view, to reflect data changes.(when opening this view second time)
            // tags:
            //      protected

            this._toolbar.update({
                currentContext: context,
                viewConfigurations: {
                    availableViews: data.availableViews,
                    viewName: data.viewName
                }
            });
        },

        layout: function () {
            // summary:
            //      Layout the children widgets.
            // tags:
            //      protected

            this.inherited(arguments);

            var listSize = domGeometry.getMarginBox(this.campaignItemList.domNode);

            var contentHeight = this._contentBox.h - (listSize.t + 10);

            // Set the size of the marketing overview to be the content height minus the toolbar height and width minus the facet width.
            this.campaignItemList.resize({
                h: contentHeight,
                w: this._contentBox.w
            });
        },

        startup: function () {
            this.inherited(arguments);
            when(this.getCurrentContext(), this.contextChanged.bind(this));
        },

        contextChanged: function (ctx, callerData) {
            this._toolbar.update({
                currentContext: ctx
            });
        },

        _onFilterChanged: function (filter) {
            this.defer(function () {
                this._campaignFacet._onSelectionChanged({ "id": "name", items: [filter.trim()] });
            }.bind(this), 500);
        },

        highlightNewlyInsertedRow: function (itemId) {
            this._campaignFacet.refresh.bind(this._campaignFacet);
            
            this.defer(function () {
                var element = document.querySelector("[data-content-link=" + itemId.itemId + "]");
                var row = element.closest(".dgrid-row");
                row.classList.add("blink-bg");

				this.defer(function() {
                    row.classList.remove("blink-bg");
                }.bind(this), 1000);
            }.bind(this), 500);
        },

        clearFilter: function() {
            this._campaignFacet._onSelectionChanged({ "id": "name", items: [] });
        }
    });
});