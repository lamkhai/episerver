require({cache:{
'url:epi-ecf-ui/widget/templates/FacetFilter.html':"<div class=\"epi-facet-filter\">\r\n    <div data-dojo-attach-point=\"dropDownNode\"></div>\r\n</div>"}});
define("epi-ecf-ui/widget/FacetFilter", [
// dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/dom-class",
    "dojo/dom-prop",
    "dojo/dom-style",
    "dojo/string",
    "dojo/query",
// dijit
    "dijit/layout/_LayoutWidget",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/DropDownMenu",
    "dijit/MenuItem",
// epi
    "epi/shell/widget/_ModelBindingMixin",
    "./CheckBoxMenuItem",
    "./FilterDropDownButton",
    "./SearchMenuItem",
// resources
    "dojo/text!./templates/FacetFilter.html",
    "epi/i18n!epi/cms/nls/commerce.widget.facets"
], function (
// dojo
    array,
    declare,
    domClass,
    domProp,
    domStyle,
    dojoString,
    query,
// dijit
    _LayoutWidget,
    _TemplatedMixin,
    _WidgetsInTemplateMixin,
    DropDownMenu,
    MenuItem,
// epi
    _ModelBindingMixin,
    CheckBoxMenuItem,
    FilterDropDownButton,
    SearchBoxMenuItem,
// resources
    template,
    resources
) {
    return declare([_LayoutWidget, _TemplatedMixin, _WidgetsInTemplateMixin], {
        // templateString: [public] string
        //      Used by _TemplatedMixin.
        templateString: template,
        resources: resources,

        name: "",
        facetContainer: "",
        facetId: "",
        items: [],
        anyLabel: resources.anyoption,
        isSearchable: false,
        isUpdatable: false,

        postCreate: function () {
            this.id = this.facetContainer + "_" + this.facetId;

            this.isUpdatable = this.isSearchable;

            this.inherited(arguments);

            this._setupDropdownButton();
        },
        _setupDropdownButton: function() {
            this._menu = new DropDownMenu({
                baseClass: "overflow-facet-filter"
            });
            this.own(this._menu,
                this._menu.on("execute", this._onMenuExecute.bind(this)),
                this._menu.on("itemClick", this._onItemClick.bind(this))
            );

            if (this.isSearchable) {
                this._setupSearchBox(this.resources.filterbyname);
            }

            this._menu.addChild(new MenuItem({label: this.anyLabel, 'class': 'epi-checkbox-menuitem'}));

            // add menu items by on item data
            array.forEach(this.items, function(item) {
                this._menu.addChild(new CheckBoxMenuItem({ label: item.name, facetId: item.id }));
            }.bind(this));

            this._dropDown = new FilterDropDownButton({
                label: this.name,
                labelValue: this.anyLabel,
                name: this.name,
                id: this.facetContainer + "_" + this.id,
                dropDown: this._menu
            });
            this.own(this._dropDown);

            this._dropDown.placeAt(this.dropDownNode);
        },
        _setupSearchBox: function(searchplaceholder) {
            var searchBox = new SearchBoxMenuItem({
                "class": "epi-search--full-width",
                triggerChangeOnEnter: false,
                onSearchBoxChange: this._onSearchBoxChange.bind(this)
            });
            searchBox.set("placeHolder", searchplaceholder);
            this._menu.addChild(searchBox);
        },
        _onSearchBoxChange: function(searchText) {
            var childMenuItems = this._menu.getChildren();
            childMenuItems.forEach(function(child) {
                if (child.label) {
                    if (searchText === "" || child.label.toLowerCase().includes(searchText.trim().toLowerCase())) {
                        domClass.remove(child.domNode, "dijitHidden");
                    } else {
                        domClass.add(child.domNode, "dijitHidden");
                    }
                }
            }.bind(this));
        },
        _onMenuExecute: function () {
            //override to not close dropdown when clicked to menu item
        },
        _onItemClick: function (item) {
            // summary:
            //      Fired when clicking on an item in the widget.
            //      Emits onFilterChanged event to its container.
            // tags:
            //      private
            // if item clicked is Any option, uncheck all options
            if (item.label === this.anyLabel) {
                this._updateAllMenuItems(false);
            }

            // update state of selected item
            this.items.forEach(function(aItem) {
                if (aItem.name === item.label) {
                    aItem.selected = item.checked;
                    return;
                }
            });

            this._updateLabelValueDropdownButton();

            this.defer(function () {
                this.onFilterChanged({ "id": this.facetId, items: this._getSelectedItems() });
            }.bind(this), 200);
        },

        _updateLabelValueDropdownButton: function() {
            var itemChecked = array.filter(this.items, function(item) { return item.selected;});
            var labelValue = "";

            if (itemChecked.length > 0) {
                // at least 1 option checked
                labelValue = itemChecked.length > 1 ? this.resources.multiple : itemChecked[0].name;
            } else {
                // none option checked
                labelValue = this.anyLabel;
            }

            this._dropDown.set("labelValue", labelValue);
        },

        _getSelectedItems: function () {
            // summary:
            //      Gets all selected item data.
            // tags:
            //      private

            var items = [];
            array.forEach(this.items, function (item, index) {
                if (item.selected) {
                    items.push(item.id);
                }
            });

            return items;
        },

        _setSelectionAttr: function (items) {
            // summary:
            //      Sets the selection in the list and emit filterChanged with the given facet items
            // tags:
            //      protected

            this._updateAllMenuItems(false);

            if (items instanceof Array) {
                var allItems = this.items,
                    validItems = items.filter(function (selectedItem) {
                        return allItems.some(function(item) {
                            return selectedItem === item.id;
                        });
                    });

                // If has an invalid item then emit filterChanged with only valid items to remove invalid item.
                if (validItems.length !== items.length) {
                    this.emit("filterChanged", { "id": this.facetId, items: validItems });
                    return;
                }

                this._setFiltersFromUrl(validItems);
            }

            this._updateLabelValueDropdownButton();
        },

        _updateAllMenuItems: function(checked) {
            array.forEach(this.items, function(item) {
                item.selected = checked;
            });
            this._menu.getChildren().map(function (menuItem) {
                menuItem.set('checked', checked);
            });
        },

        _setFiltersFromUrl: function(validItems) {
            var childNodes = this._menu.getChildren();
            validItems.forEach(function(value){
                this.items.forEach(function(aItem) {
                    if (aItem.id === value) {
                        aItem.selected = true;
                        return;
                    }
                });
                childNodes.forEach(function (menuItem) {
                    if (menuItem.facetId === value) {
                        menuItem.set('checked', true);
                        return;
                    }
                });
            }.bind(this));
        },

        onFilterChanged: function(data) {
        }

    });
});