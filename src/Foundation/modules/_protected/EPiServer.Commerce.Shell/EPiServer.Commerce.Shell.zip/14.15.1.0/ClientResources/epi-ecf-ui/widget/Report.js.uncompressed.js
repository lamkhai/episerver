require({cache:{
'url:epi-ecf-ui/widget/templates/Report.html':"<div data-dojo-type=\"dijit/layout/ContentPane\" class=\"epi-list-container\" style=\"display: none\">\r\n</div>\r\n"}});
define("epi-ecf-ui/widget/Report", [
    // dojo
    "dojo/_base/declare",
    // dijit
    "dijit/_TemplatedMixin",
    "dijit/_WidgetBase",
    //template
    "dojo/text!./templates/Report.html",
    // Resources
    "epi/i18n!epi/cms/nls/commerce.report"
],

    function (
        // dojo
        declare,
        // dijit
        _TemplatedMixin,
        _WidgetBase,
        //template
        template,
        // Resources
        resources
    ) {
        // module:
        //      epi-ecf-ui.widget.Report

        return declare([_WidgetBase, _TemplatedMixin], {
            // summary:
            //      Settings widget.
            // tags:
            //      public

            templateString: template,

            resources: resources,

            baseUrl: null,

            location: null,

            postMixInProperties: function () {
                this.inherited(arguments);
                this.baseUrl = this.baseUrl || this._constructUrl();
            },

            _constructUrl: function () {
                var location = this.location || window.top.location;
                var host = location.protocol + "//" + location.hostname;
                if (location.port) {
                    host = host + ":" + location.port;
                }
                return host + location.pathname;
            }
        });
    });