require({cache:{
'url:epi-ecf-ui/widget/viewmodel/templates/DatePeriodColumnHeader.html':"﻿<div class=\"status-label ${badgeStatus}\">${headingLabel}</div>\r\n<div>\r\n    <span class=\"epi-text-cell\"><span class=\"epi-from-date\">${fromDate}</span> - ${toDate}</span>\r\n</div>"}});
﻿define("epi-ecf-ui/widget/DiscountList", [
// dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/dom-geometry",
    "dojo/dom-class",
    "dojo/html",
    "dojo/query",
    "dojo/promise/all",
    "dojo/string",
    "dojo/when",
    // epi
    "epi/datetime",
    "epi/dependency",
// epi-cms
    "epi-cms/core/ContentReference",
// epi-ecf-ui
    "../MarketingUtils",
    "./_ConfirmDiscardChangesMixin",
    "./_MarketingListBase",
    "./DiscountSelector",
    "./MoveDiscountDialog",
    "./viewmodel/DiscountListModel",
// resources
    "epi/i18n!epi/nls/commerce.widget.marketingitemlist",
    "epi/i18n!epi/nls/commerce.widget.marketingtoolbar",
    "dojo/text!./viewmodel/templates/DatePeriodColumnHeader.html"
], function (
// dojo
    array,
    declare,
    lang,
    domGeometry,
    domClass,
    html,
    query,
    all,
    dojoString,
    when,
    // epi
    epiDate,
    dependency,
// epi-cms
    ContentReference,
// epi-ecf-ui
    MarketingUtils,
    _ConfirmDiscardChangesMixin,
    _MarketingListBase,
    DiscountSelector,
    MoveDiscountDialog,
    DiscountListModel,
// resources
    marketingResources,
    marketingToolbarResources,
    datePeriodColumnHeaderTemplate
) {
    return declare([_MarketingListBase, _ConfirmDiscardChangesMixin], {
        // summary:
        //      A widget to list all promotions
        // tags:
        //      public

        // contextChangeEvent: [public] string
        //      Disable the double click action to grid item.
        contextChangeEvent: "",

        // typeIdentifiers: [public] Array
        //      Overrides base class properties in order to get promotion data only.
        typeIdentifiers: [
            MarketingUtils.contentTypeIdentifier.promotionData
        ],

        _discountSelectorDialog: null,
        _moveDiscountDialog: null,
        _discountSelected: null,

        postCreate: function () {
            this._facetFiltersService = this._facetFiltersService || dependency.resolve("epi.commerce.DiscountFacetFiltersService");
            
            this.inherited(arguments);

            domClass.add(this.grid.domNode, "epi-discount-list");
        },

        startup: function () {
            this.inherited(arguments);

            this.own(
                this.model.on("item-move", this._showMoveDiscountDialog.bind(this)),
                this.model.on("item-moved", function () {
                    this.save();
                    lang.hitch(this, this.updateList, true);
                }.bind(this)));
        },

        refresh: function () {
            // Refresh list after edit
            if (this.get("currentView") !== "discountpriorityview") {
                this.model.clearAllItems();
            } else {
                this.refreshList();
            }
        },

        updateList: function (enabled) {
            // summary:
            //      Turn on/off grid's on demand load feature.
            // enabled: [bool]
            //      Flag to indicated that the grid should query to server or not
            // tags:
            //      public

            this.grid.set("store", enabled ? this.store : null, this.getQuery());
        },

        createModel: function () {
            // tags:
            //      public, extensions

            return new DiscountListModel({ store: this.store });
        },

        getListSettings: function () {
            // summary:
            //      Override grid's settings
            // tags:
            //      public, extensions

            var self = this,
                baseSettings = this.inherited(arguments);

            return lang.mixin(baseSettings, {
                dndDisabled: true,
                showHeader: true,
                onContextMenuClick: function (e) {
                    this.inherited(arguments);

                    self.onContextMenuClick(e);
                },
                renderArray: function () {
                    return when(this.inherited(arguments), function (results) {
                        // After calling the inherited renderArray function we clear the noDataNode.
                        // This forces the grid to create a new node every time a campaign does not have any promotion.
                        self.grid.noDataNode = null;
                        if (results.length > 0) {
                            var items = [];
                            for (var i = 0, length = results.length; i < length; i++) {
                                var row = results[i],
                                    item = self.grid.row(row).data;
                                items.push(item);

                                domClass.add(row, [self.getItemClass(item), self.getItemStatusClass(item)]);
                                var orderCell = query(".field-order", row)[0];
                                if (orderCell) {
                                    html.set(orderCell, (row.rowIndex + 1).toString());
                                }
                            }
                            self.model.set("items", items);
                        } else {
                            // No result
                            var isUsingFilter = self.grid.query && self.grid.query.discountFacets !== '{}';
                            var isNoDiscount = Object.keys(self.grid._rowIdToObject).length === 0;
                            if (isNoDiscount) {
                                self.grid.noDataMessage = isUsingFilter ? marketingResources.emptydiscountdatafilter : marketingResources.emptydiscount;
                            }
                        }

                        return results;
                    });
                }
            });
        },

        getQuery: function () {
            // tags:
            //      public, extensions

            var baseQuery = this.inherited(arguments);

            return lang.delegate(baseQuery, {
                query: this.model.queryName,
                referenceId: this.model.campaignRootFolder,
                discountFacets: this._facetFiltersService.getFiltersAsJson(),
                isActiveOrPendingOnly: true
            });
        },

        onContextMenuClick: function (e) {
            // summary:
            //      Setup command model of selected row.
            // tags:
            //      public, extensions

            this.inherited(arguments);

            var selectedItem = this.grid.row(e).data;
            this.model.updateCommandModel({ currentRowItem: selectedItem });
        },

        setupEvents: function () {
            // tags:
            //      public, extensions

            this.own(
                this.model.on("items-saved", lang.hitch(this, this.refresh, true))
            );
        },

        resize: function (changedSize) {
            this.inherited(arguments);

            var height = domGeometry.getContentBox(this.domNode).h;
            domGeometry.setContentSize(this.gridNode, { h: height });
            
            if (this._moveDiscountDialog) {
                this._moveDiscountDialog.resize(document.documentElement.scrollHeight);
            }
        },

        save: function () {
            // summary:
            //      Call save priority data.
            // return:
            //      Deferred object.
            // tags:
            //      publish

            return this.model.save();
        },

        clearItems: function () {
            // summary:
            //      Clear the local representation of the items collection.
            // tags:
            //      Public

            this.model.items = [];
        },

        getColumnSettings: function () {
            // tags:
            //      public, extensions

            return {
                index: {
                    label: 'Priority No',
                    className: "priorityNo",
                    renderCell: function (item, value, node, options) {
                        return this._renderPriorityValue(item, node);
                    }.bind(this),
                    sortable: false,
                    resizable: false
                },
                name: {
                    label: 'Discount Name',
                    className: "epi-grid--35",
                    get: this.model._getNameModel.bind(this.model),
                    formatter: this._getNameHtml.bind(this),
                    sortable: false,
                    resizable: false
                },
                daterange: {
                    label: 'Status',
                    className: "epi-grid--15",
                    get: this.model._getStatusModel.bind(this.model),
                    formatter: this._getStatusHtml,
                    sortable: false,
                    resizable: false
                },
                campaign: {
                    label: 'Campaign',
                    className: "epi-grid--25",
                    get: function (item) {
                        return item.properties.campaignName;
                    },
                    sortable: false,
                    resizable: false
                },
                exclusion: {
                    label: 'Exclude From',
                    className: "epi-grid-column--left exclude-from-column epi-grid--35",
                    renderCell: function (item) {
                        return this._getDiscountSelector(item).domNode;
                    }.bind(this),
                    sortable: false,
                    resizable: false
                }
            };
        },

        _renderPriorityValue: function (item, node) {
            if (this.model.allItems === null) {
                when(this.model.getAllItems()).then(function (results) {
                    this.model.setAllItems(results);
                    node.innerHTML = this.model._getItemIndex(item.contentLink) + 1;
                }.bind(this));
            } else {
                node.innerHTML = this.model._getItemIndex(item.contentLink) + 1;
            }
        },

        _getDiscountSelector: function (item) {
            // summary:
            //      Gets an instance of DiscountSelector widget.
            // item: [Object]
            //      Promotion data object.
            // tags:
            //      private

            var widget = new DiscountSelector({
                excludedLink: item.contentLink,
                dialog: this._discountSelectorDialog,
                ownDialog: false,
                store: this.store,
                campaignRootFolder: this.model.campaignRootFolder
            });

            if (!this._discountSelectorDialog) {
                this._discountSelectorDialog = widget.dialog;
                this.own(this._discountSelectorDialog);
            }

            widget._onChangeActive = false;
            var selectedLinks = item.properties.excludedItems || [],
                selectedContents = [];
            all(array.map(selectedLinks, function (contentLink) {
                return when(this.model.store.get(contentLink), function (content) {
                    if (content) {
                        if (ContentReference.compareIgnoreVersion(content.contentLink, this.model.campaignRootFolder)) {
                            content.name = marketingToolbarResources.allcampaigns;
                        }

                        selectedContents.push(content);
                    }
                }.bind(this));
            }, this)).then(function () {
                widget.set("value", selectedContents);
                widget._onChangeActive = true;
            });

            this.own(
                widget,
                widget.on("change", function (selectedItems) {
                    this.model.onSelectorValueChanged(item, selectedItems);
                }.bind(this))
            );

            return widget;
        },

        _getStatusHtml: function (model) {
            // tags:
            //      private

            return dojoString.substitute(datePeriodColumnHeaderTemplate, {
                badgeStatus: model.statusLabelKey,
                headingLabel: marketingResources.status[model.statusLabelKey],
                fromDate: epiDate.toUserFriendlyString(model.validFrom, null, null, true),
                toDate: epiDate.toUserFriendlyString(model.validUntil, null, null, true)
            });
        },

        _showMoveDiscountDialog: function (discount) {
            if (this._moveDiscountDialog) {
                this._moveDiscountDialog.hide();
                this._moveDiscountDialog = null;
            }

            this._moveDiscountDialog = new MoveDiscountDialog({
                dialogClass: "epi-marketing-move-discount",
                destroyOnHide: true,
                draggable: false,
                discountLink: discount.contentLink
            });

            this.own(
                this._moveDiscountDialog,
                this._moveDiscountDialog.on("execute", this._onMoveDiscount.bind(this)),
                this._moveDiscountDialog.on("hide", this._onCancelMoveDiscount.bind(this)));

            this._discountSelectedLink = discount.contentLink;
            this._moveDiscountDialog.updateDescriptionForDialog(discount.name);

            var items = this.model.get("allItems");
            if (items) {
                this._moveDiscountDialog.content.setTotalItems(items.length);
            } else {
                this._moveDiscountDialog.content.setTotalItems(0);
            }

            this._moveDiscountDialog.show();
            this._moveDiscountDialog.resize(document.documentElement.scrollHeight);
        },

        _onMoveDiscount: function () {
            var data = this._moveDiscountDialog.content.get("value");
            if (!dojo.isObject(data)) {
                return;
            }
            switch (data.mode) {
                case 0:
                    this.model.changePriority(this._discountSelectedLink, data.value);
                    break;
                case 1:
                    this.model.moveItem(this._discountSelectedLink, data.value, true);
                    break;
                case 2:
                    this.model.moveItem(this._discountSelectedLink, data.value, false);
                    break;
            }
        },

        _onCancelMoveDiscount: function () {
            this._moveDiscountDialog.hide();
            this._moveDiscountDialog = null;
        }
    });
});