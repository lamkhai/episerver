require({cache:{
'url:epi-ecf-ui/widget/templates/MoveDiscountDialogContent.html':"﻿<div data-dojo-attach-point=\"moveDiscountDialogContent\" class=\"moveDiscountDialogContent\">\r\n    <div class=\"move-discount-selector radio-full-width-option\">\r\n        <input data-dojo-type=\"dijit/form/RadioButton\" data-dojo-attach-point=\"moveToDiscount\" checked\r\n            name=\"moveOption\" id=\"moveto-discount\" />\r\n        <label class=\"dijitInline\" for=\"moveto-discount\">${resources.moveto}</label>\r\n        <div class=\"selector-content\" data-dojo-attach-point=\"moveToContainer\">\r\n            <input style=\"width: 100%;\" type=\"number\" min=\"1\" data-dojo-type=\"dijit/form/TextBox\" data-dojo-attach-point=\"moveToContent\" autofocus\r\n                placeholder=\"${resources.movetoplaceholder}\" data-dojo-props=\"intermediateChanges:true\" />\r\n            <span data-dojo-attach-point=\"moveToLabel\" style=\"font-size:12px; color: red;display:none;\"></span>\r\n        </div>\r\n    </div>\r\n    <div class=\"move-discount-selector\">\r\n        <input data-dojo-type=\"dijit/form/RadioButton\" data-dojo-attach-point=\"moveAboveDiscount\" \r\n            name=\"moveOption\" id=\"move-above-discount\" />\r\n        <label class=\"dijitInline\" for=\"move-above-discount\">${resources.moveabove}</label>\r\n        <div class=\"selector-content\" data-dojo-attach-point=\"moveAboveContainer\"> \r\n            <select name=\"aboveSelect\" data-dojo-attach-point=\"moveAboveSelector\" \r\n                data-dojo-type=\"epi-ecf-ui/widget/MoveDiscountSelector\">\r\n            </select>\r\n        </div>\r\n    </div>\r\n    <div class=\"move-discount-selector\">\r\n        <input data-dojo-type=\"dijit/form/RadioButton\" data-dojo-attach-point=\"moveBelowDiscount\" \r\n            name=\"moveOption\" id=\"move-below-discount\" />\r\n        <label class=\"dijitInline\" for=\"move-below-discount\">${resources.movebelow}</label>\r\n        <div class=\"selector-content\" data-dojo-attach-point=\"moveBelowContainer\">\r\n            <select name=\"belowSelect\" data-dojo-attach-point=\"moveBelowSelector\" \r\n                data-dojo-type=\"epi-ecf-ui/widget/MoveDiscountSelector\">\r\n            </select>\r\n        </div>\r\n    </div>\r\n</div>\r\n"}});
﻿define("epi-ecf-ui/widget/MoveDiscountDialogContent", [
  // dojo
  "dojo/_base/declare",
  "dojo/on",
  "dojo/dom-class",
  "dojo/dom-style",
  // dijit
  "dijit/_WidgetBase",
  "dijit/_TemplatedMixin",
  "dijit/_WidgetsInTemplateMixin",
  // epi
  "epi/shell/widget/_ModelBindingMixin",
   "./MoveDiscountSelector",
  // resources
  'dojo/text!./templates/MoveDiscountDialogContent.html',
  "epi/i18n!epi/nls/commerce.widget.movediscountdialog"
], function (
  // dojo
  declare,
  on,
  domClass,
  domStyle,
  // dijit
  _WidgetBase,
  _TemplatedMixin,
  _WidgetsInTemplateMixin,
  // epi
  _ModelBindingMixin,
  MoveDiscountSelector,
  // resources
  templates,
  resources
) {

  function setVisibility(widget, visible) {
    domStyle.set(widget, "display", visible? "block": "none");
  }

  return declare([_WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin, _ModelBindingMixin], {
    // summary:
    //      Represents the widget which contains the move discount content.
    // tags:
    //    internal product

    templateString: templates,
    resources: resources,
    excludedLink: null,
    totalItems: 0, //total promotions, used for validate Priority Value.

    moveOption: {
      moveTo: 0,
      moveAbove: 1,
      moveBelow: 2
    },

    postCreate: function () {
      this.inherited(arguments);

      this.moveAboveSelector = this.moveAboveSelector || new MoveDiscountSelector();
      this.moveBelowSelector = this.moveBelowSelector || new MoveDiscountSelector();
      
      setVisibility(this.moveAboveContainer, false);
      setVisibility(this.moveBelowContainer, false);

      this.moveToContent.domNode.onkeypress = this._moveToContentKeyPress;

      this.own(
         this.moveToDiscount,
         this.moveAboveDiscount,
         this.moveBelowDiscount,
         this.moveToContent,
         this.moveAboveSelector,
         this.moveBelowSelector,

         this.moveToDiscount.on("click", this._updateVisibility.bind(this, this.moveOption.moveTo)),
         this.moveAboveDiscount.on("click", this._updateVisibility.bind(this, this.moveOption.moveAbove)),
         this.moveBelowDiscount.on("click", this._updateVisibility.bind(this, this.moveOption.moveBelow)),

         this.moveToContent.on('change', this._handlePriorityChanged.bind(this, this.moveOption.moveTo)),
         this.moveAboveSelector.on('change', this._handlePriorityChanged.bind(this, this.moveOption.moveAbove)),
         this.moveBelowSelector.on('change', this._handlePriorityChanged.bind(this, this.moveOption.moveBelow))
      );
    },

    setExcludedLink: function (excludedLink) {
        this.excludedLink = excludedLink;
        this.moveBelowSelector.set("excludedLink", excludedLink);
        this.moveAboveSelector.set("excludedLink", excludedLink);
        this.moveBelowSelector.refresh();
        this.moveAboveSelector.refresh();
    },

    setTotalItems: function(totalItems) {
        this.totalItems = totalItems;
        this.moveToLabel.innerText = "Please enter a priority no between 1 & " + this.totalItems;
    },

    _moveToContentKeyPress: function (e) {
      return (e && !isNaN(e.key));
    },

    _handlePriorityChanged: function (mode, value) {
      var priorityModel = {
        mode: mode,
        value: value
      };

      if (mode === this.moveOption.moveTo) {
          if (value === '' || value === null || value === undefined) {
              domClass.remove(this.moveToContent.domNode, "epi-field-error");
              domStyle.set(this.moveToLabel, "display", "none");
          } else {
              var priorityValue = parseInt(value, undefined);
              if (isNaN(priorityValue) || priorityValue < 1 || priorityValue > this.totalItems) {
                  domClass.add(this.moveToContent.domNode, "epi-field-error");
                  domStyle.set(this.moveToLabel, "display", "block");
              } else {
                  domClass.remove(this.moveToContent.domNode, "epi-field-error");
                  domStyle.set(this.moveToLabel, "display", "none");
              }
          }
        }

      this._set("value", priorityModel);
      this.emit("move-option-changed", { isValid: this._validatePriorityModel(priorityModel)});
    },

    _updateVisibility: function (mode) {
      this._hiddenAllOptions();
      var optionValue;
      switch (mode) {
        case this.moveOption.moveTo:
          setVisibility(this.moveToContainer, true);
          optionValue = this.moveToContent.get("value");
          break;
        case this.moveOption.moveAbove:
          setVisibility(this.moveAboveContainer, true);
          optionValue = this.moveAboveSelector.get("value");
          break;
        case this.moveOption.moveBelow:
          setVisibility(this.moveBelowContainer, true);
          optionValue = this.moveBelowSelector.get("value");
          break;
      }

      var priorityModel = {
        mode: mode,
        value: optionValue
      };

      this._set("value", priorityModel);
      this.emit("move-option-changed", { isValid: this._validatePriorityModel(priorityModel)});
    },

    _hiddenAllOptions: function() {
      setVisibility(this.moveToContainer, false);
      setVisibility(this.moveAboveContainer, false);
      setVisibility(this.moveBelowContainer, false);
    },

    _validatePriorityModel: function (priorityModel) {
      if (priorityModel && dojo.isString(priorityModel.value) && priorityModel.value !== "") { 
          if (priorityModel.mode === this.moveOption.moveTo) {
              var priorityValue = parseInt(priorityModel.value, undefined);
              if (isNaN(priorityValue) || priorityValue < 1 || priorityValue > this.totalItems) {
                  return false;
              }
          }
          return true; 
      }
      return false;
    }
  });
});