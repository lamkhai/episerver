//>>built
define("epi-ecf-ui/widget/CommandToggleButton",["dojo/_base/declare","dijit/form/ToggleButton","epi/shell/command/_CommandModelBindingMixin"],function(_1,_2,_3){return _1([_2,_3]);});