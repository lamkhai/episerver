﻿define("epi-ecf-ui/contentediting/editors/AmountEditor", [
// dojo
    "dojo/_base/declare",
    "dojo/currency",
    "dojo/keys",
    "dojo/number",
    "dojo/on",
// dijit
    "dijit/form/CurrencyTextBox",
// resources
    "epi/i18n!epi/cms/nls/commerce.widget.moneylisteditor"
], function(
// dojo
    declare,
    currency,
    keys,
    number,
    on,
// dijit
    CurrencyTextBox,
// resources
    resources
){
    return declare([CurrencyTextBox], {

        postCreate: function(){
            this.inherited(arguments);

            this.set("constraints", {
                min: 0,
                symbol: " " // This will hide the currency symbol in the editor.
            });

            this.set("placeholder", resources.undefinedamount);
            this.set("rangeMessage", resources.invalidamount);
            this.own(on(this.domNode, "keydown", this._onKeyDown.bind(this)));
        },

        onChange: function (newValue) {
            // Any zero values should be replaced by empty strings causing the textbox
            // to show its placeholder text instead.
            if (newValue === 0) {
                this.set("value", "");
            }
        },

        _onKeyDown: function (event) {
            if (event.keyCode === keys.ENTER) {
                // Hitting the ENTER key should enable
                // any existing save button on the parent form.
                this.set("value", this.get("value"));
            }
        },

        _getDisplayedValueAttr: function(){
            var originalValue = this.inherited(arguments);
            if (!originalValue){
                return originalValue;
            }

            // we use number.parse here to make sure we get the number as it is written.
            // currency.parse will return NaN for valid numbers
            var parsedValue = number.parse(originalValue);
            if (isNaN(parsedValue)){
                return originalValue;
            }
            // the currency textbox will set places on the constraints depending on
            // what currency is has. This code will ensure that any valid value
            // will always display the correct amount of decimals by padding zeroes at the end.
            var paddedValue = parsedValue.toFixed(this.constraints.places);

            // if the padded value is a different float than the original value we should
            // return the original value as that means we've rounded a number with more decimals
            // than allowed and we want to avoid that.
            return  number.parse(paddedValue) === number.parse(originalValue) ?
                currency.format(paddedValue, this.constraints) : originalValue;
        }
    });
});