if (typeof $$epiforms !== 'undefined') {
    $$epiforms(document).ready(function () {
        $$epiforms('.EPiServerForms, [data-f-type="form"]').on("formsNavigationNextStep formsSetupCompleted", function (event) {
            (function ($) {
                var originalText = $("#___FormElementGuid___" + "__OriginalText", $workingForm).html(),
                    workingFormInfo = event.workingFormInfo,
                    searchPattern = null,
                    $workingForm = workingFormInfo.$workingForm,
                    $currentElement = $("#___FormElementGuid___", $workingForm);

                // if cannot find the element in form, do nothing
                if (!$currentElement || $currentElement.length == 0) {
                    return;
                }

                var data = epi.EPiServer.Forms.Data.loadFormDataFromStorage(workingFormInfo.Id);

                // In case the element is not under the form folder, Model.HasPlaceHolder() will return false because of cannot find the owner form.
                // So when Model.FindOwnerForm() is null, we allow to replace the placeholder in JS mode.
                if (___DoPlaceholder___) { 
                    // replace placeholder with real field value
                    for (var fieldName in workingFormInfo.ElementsInfo) {
                        if (workingFormInfo.FieldsExcludedInSubmissionSummary.indexOf(fieldName) != -1) {
                            continue;
                        }
                        var elementInfo = workingFormInfo.ElementsInfo[fieldName],
                            friendlyName = elementInfo.friendlyName;
                        if (!friendlyName) {
                            continue;
                        }
                        var value = elementInfo && elementInfo.customBinding == true ?
                            epi.EPiServer.Forms.CustomBindingElements[elementInfo.type](elementInfo, data[fieldName])
                            : data[fieldName];
                        if (value == null || value === undefined) {
                            value = "";
                        }

                        // If the element is inactive (hidden due to dependency rules), set its value to empty
                        if (epi.EPiServer.Forms.Dependency._isInactiveElement(fieldName, workingFormInfo)) {
                            value = "";
                        }

                        //We have to encode the friendlyName before replacing it with placeholders in the paragraph text because the paragraph text is already encoded.
                        var encodedFriendlyName = $('<div></div>').text(friendlyName).html();

                        //https://developer.mozilla.org/en/JavaScript/Reference/Global_Objects/String/replace
                        //https://msdn.microsoft.com/en-us/library/ewy2t5e0.aspx
                        var escapeSpecialCharacterFromEncodedFriendlyName = encodedFriendlyName.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');

                        // Add backward compatible for old placeholder key
                        searchPattern = new RegExp("(?:#|::)" + escapeSpecialCharacterFromEncodedFriendlyName + "(?:#|::)", 'gi');
                        originalText = originalText.replace(searchPattern, $('<div></div>').text(value).html());
                    }
                }
                $currentElement.html(originalText);
            })($$epiforms);
        });
    });
}
